﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;
using UnityEngine.Advertisements;
using UnityEngine.SceneManagement;

public class LoseScr_Controller : MonoBehaviour {

    public GameObject playButton;
    public Image[] coloredUI;

    public GameObject gameover1;
    public GameObject gameover2;

    private float elapsedTime;
    public float maxTime;

    //private byte cb = 0;
    
	void Start () {
        EnableButtons();

        //Time.timeScale = 0f;
    }
	
	void Update () {
        elapsedTime += Time.deltaTime;
        if (elapsedTime >= maxTime)
        {
            if (Main_Controller.currentMenu == Main_Controller.MENU.LOSE && !Advertisement.isShowing)
            {
                SceneManager.LoadScene(0);
            }
        }
	
	}

    void EnableButtons()
    {
        playButton.SetActive(true);
        gameover1.SetActive(true);
        gameover2.SetActive(true);
    }
    
    public void PlayButton()
    {
        if (Main_Controller.currentMenu == Main_Controller.MENU.LOSE && !Advertisement.isShowing)
        {
            SceneManager.LoadScene(0);
        }

    }
}
