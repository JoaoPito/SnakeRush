﻿using UnityEngine;
using System.Collections;

public class Background_Controller : MonoBehaviour {

    public GameObject[] bkgObjects;
    public int InstantiateTime;
    public float bkgSpeed;

    private int randomIndex;
    private GameObject currentBkg;

    public Transform player;

	void Start () {

        if (player == null)
        {
            player = GameObject.FindWithTag("Player").transform;
        }

        randomIndex = Random.Range(0, bkgObjects.Length);

        currentBkg = Instantiate(bkgObjects[randomIndex], new Vector3(player.transform.position.x-20, player.transform.position.y - 20, player.transform.position.z - 20), Quaternion.identity) as GameObject;

        InvokeRepeating("InstantiateBkg", InstantiateTime, InstantiateTime);
	
	}

	void Update () {

        if (currentBkg != null)
        {
            if (Vector3.Distance(player.position,currentBkg.transform.position)>70)
            {
            Destroy(currentBkg.gameObject);
            }
            currentBkg.transform.Translate(0, 0, bkgSpeed * Time.deltaTime);
        }
	}

    void InstantiateBkg()
    {
        randomIndex = Random.Range(0, bkgObjects.Length);

        currentBkg = Instantiate(bkgObjects[randomIndex],new Vector3(player.transform.position.x-20, player.transform.position.y-20, player.transform.position.z-20),Quaternion.identity) as GameObject;
    }
}
