﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;
using UnityEngine.Advertisements;
using UnityEngine.SceneManagement;

public class Main_Controller : MonoBehaviour {

    public enum MENU
    {
        LOGO,
        QUIT,
        MAINMENU,
        PLAY,
        PAUSE,
        LOSE,
        SHOP,
        LEVELFINISH,
    }

     static public MENU currentMenu = MENU.MAINMENU;

    public Point_Controller pointsController;
    public float changeColorTime;

    public Material sideMat;
    public Material groundMat;

    public Material UIMat;

    public Color[] sideMatColor;
    public Color loseColor;
    
    private int randomColor;
    private bool changeColor;

    public float LogoTime;
    private float currentLogoTime;
    public EasyTween SBLogo;

    public Text versionTxt;

    public GUISkin guiSkin;

    public LoseScr_Controller loseController;
    public Player_Movement playerScr;

    public GameObject settingsButton;
	public GameObject levelsButton;
	public GameObject storeButton;
    public GameObject setMusicButton;

    public GameObject SRLogo;

    public Text tapToPlayTxt;

    public Shop_Controller shopScr;

    private bool tapScreen = true;

    public GameObject pauseButton;
    public GameObject pauseText;

    //Advertisement
    public bool showAds = false;

    public float AdChance = 0;
    public GameObject AdShow;
    public Text adText;
    private int rewardedPoints;
    private bool showedAd = false;

    //Level Finish
    public GameObject levelFinishButton;
    public GameObject levelTime;
    public GameObject levelBestTime;

    public Transform loseFog;

    void Start () {

        currentMenu = Main_Controller.MENU.MAINMENU;

        versionTxt.text = string.Concat(versionTxt.text, Application.version.ToString());

        InvokeRepeating("ChangeColor", 0, changeColorTime);

        pointsController.currentPoints = pointsController.LoadPoints();
        
        rewardedPoints = Random.Range(5, 20);

        if (playerScr == null)
        {
            playerScr = GameObject.FindWithTag("Player").GetComponent<Player_Movement>();
        }
    }

    void Update() {

        switch (currentMenu) {
            
            case MENU.LOGO:

                if (currentLogoTime == 0)
                    SBLogo.OpenCloseObjectAnimation();
                
                if(currentLogoTime>= LogoTime)
                {
                    SBLogo.OpenCloseObjectAnimation();
                    currentMenu = MENU.MAINMENU;
                    currentLogoTime = -1;
                }
                else
                {
                    currentLogoTime += Time.deltaTime;
                }
                break;

            case MENU.MAINMENU:

                storeButton.SetActive(true);
                settingsButton.SetActive(true);
                tapToPlayTxt.enabled = true;

                SRLogo.SetActive(true);
                break;

            case MENU.LOSE:

                if (showAds && Advertisement.isSupported && CheckInternet())
                {
                    if (AdChance == 0)
                        AdChance = Random.value * 10;

                    if (AdChance < 0.5f)
                    {
                        if (!showedAd)
                        {
                            Advertisement.Show();
                            showedAd = true;
                        }
                    }
                    else
                    {
                        if (AdChance > 5)
                        {
                            AdShow.SetActive(true);
                            adText.text = string.Concat("+", rewardedPoints.ToString());
                        }
                    }
                }

                if (loseController.enabled == false && !Advertisement.isShowing)
                    loseController.enabled = true;

                sideMat.color = Color.Lerp(sideMat.color,loseColor,Time.deltaTime*10);

                break;

            case MENU.LEVELFINISH:

                levelFinishButton.SetActive(true);
                levelTime.SetActive(true);
                levelBestTime.SetActive(true);

                break;

            case MENU.PLAY:

                if (playerScr.playerDistance > 2)
                {
                    loseFog.Translate(0, 0, -(playerScr.walkSpeed * 0.75f) * Time.deltaTime);
                }

                if (Input.GetKey("m"))
                    ChangeColor();

                break;
    }


        if (currentMenu != MENU.MAINMENU)
        {
            setMusicButton.SetActive(false);
            settingsButton.SetActive(false);
            tapToPlayTxt.enabled = false;

            SRLogo.SetActive(false);

            if (currentMenu == MENU.SHOP)
            {
                storeButton.SetActive(true);
            }
            else
            {
                storeButton.SetActive(false);
            }
        }
        
        //Back Button Controls
        if (Input.GetKeyUp(KeyCode.Escape))
        {
            switch (currentMenu)
            {
                case MENU.MAINMENU:
                    currentMenu = MENU.QUIT;
                    break;

                case MENU.QUIT:
                    Application.Quit();
                    break;

                case MENU.SHOP:

                    shopScr.skinStartButton.GetComponent<EasyTween>().OpenCloseObjectAnimation();
                    shopScr.levelStartButton.GetComponent<EasyTween>().OpenCloseObjectAnimation();

                    if (shopScr.currentShopMenu == Shop_Controller.MENUS.MAIN)
                    {
                        shopScr.Exit();
                        shopScr.enabled = false;
                        shopScr.background.GetComponent<EasyTween>().OpenCloseObjectAnimation();
                    }
                    else
                    {
                        if (shopScr.currentShopMenu == Shop_Controller.MENUS.LEVELS)
                        {
                            shopScr.Exit();
                        }
                        else if (shopScr.currentShopMenu == Shop_Controller.MENUS.SKINS)
                        {
                            shopScr.Exit();
                        }

                        shopScr.currentShopMenu = Shop_Controller.MENUS.MAIN;
                    }
                    break;

                case MENU.PLAY:
                    currentMenu = MENU.PAUSE;
                    pauseText.GetComponent<EasyTween>().OpenCloseObjectAnimation();
                    break;

                case MENU.PAUSE:
                    currentMenu = MENU.MAINMENU;
                    SceneManager.LoadScene(0);
                    break;
            }
        }

        if (currentMenu == MENU.PLAY || currentMenu == MENU.PAUSE)
        {
            pauseButton.SetActive(true);
        }
        else
        {
            pauseButton.SetActive(false);
        }

        //Exit Pause
        if (currentMenu == MENU.PAUSE)
        {
            pauseText.SetActive(true);
        }

        if (changeColor)
        {
            if (changeColorTime < 5)
            {
                sideMat.color = Color.Lerp(sideMat.color, sideMatColor[randomColor], 3*Time.deltaTime);
                UIMat.color = Color.Lerp(UIMat.color, sideMatColor[randomColor], 3*Time.deltaTime);
                changeColorTime += Time.deltaTime;
            }
            else
            {
                changeColorTime = 0;
                changeColor = false;
            }
        }

	}

    void OnGUI()
    {
        GUI.skin = guiSkin;

        if (currentMenu == MENU.MAINMENU && tapScreen)
        {
            if(GUI.Button(new Rect(-10, Screen.height/5, Screen.width+20, Screen.height/1.7f), ""))
            {
                currentMenu = MENU.PLAY;
            }


        }
    }

    void ChangeColor()
    {
            randomColor = Random.Range(0, sideMatColor.Length - 1);
            changeColor = true;
            changeColorTime = 0;
    }

    //Ads Controller
    public void ShowAd()
    {
        if (Advertisement.IsReady())
        {
            Advertisement.Show();
        }
    }

    public void ShowRewardedAd()
    {
        if (Advertisement.IsReady("rewardedVideo"))
        {
            var options = new ShowOptions { resultCallback = HandleShowResult };
            Advertisement.Show("rewardedVideo", options);
        }
    }

    private void HandleShowResult(ShowResult result)
    {
        switch (result)
        {
            case ShowResult.Finished:
                Debug.Log("The ad was successfully shown.");

                if (pointsController.currentPoints < pointsController.currentPoints + rewardedPoints)
                {
                    pointsController.currentPoints += rewardedPoints;
                    pointsController.SavePoints();
                }

                break;
            case ShowResult.Skipped:
                Debug.Log("The ad was skipped before reaching the end.");
                break;
            case ShowResult.Failed:
                Debug.LogError("The ad failed to be shown.");
                break;
        }
    }

    //Settings buttons functions
    public void SettingsButton()
    {
        if (currentMenu == MENU.MAINMENU)
        {
            setMusicButton.SetActive(true);
        }
    }

    public void SettEraseButton()
    {
        PlayerPrefs.DeleteAll();
        currentMenu = MENU.MAINMENU;
        SceneManager.LoadScene(0);
    }

    public void SettMusicButton()
    {

    }

    //Shop buttons functions
    public void ShopButton()
    {
        
        if (currentMenu == MENU.MAINMENU)
        {
            shopScr.enabled = true;
            shopScr.background.GetComponent<EasyTween>().OpenCloseObjectAnimation();
        }

        if(currentMenu == MENU.SHOP)
        {

            if (shopScr.currentShopMenu == Shop_Controller.MENUS.MAIN)
            {
                shopScr.Exit();
                shopScr.enabled = false;
                shopScr.background.GetComponent<EasyTween>().OpenCloseObjectAnimation();
            }
            else
            {
                if (shopScr.currentShopMenu == Shop_Controller.MENUS.LEVELS)
                {
                    shopScr.Exit();
                }
                else if(shopScr.currentShopMenu == Shop_Controller.MENUS.SKINS)
                {
                    shopScr.Exit();
                }

                shopScr.currentShopMenu = Shop_Controller.MENUS.MAIN;
            }
            
        }
    }

    public void PauseButton()
    {
        if (currentMenu == MENU.PLAY)
        {
            currentMenu = MENU.PAUSE;
        }
        else
        {
            pauseText.SetActive(false);

            currentMenu = MENU.PLAY;
        }
    }

    //Level Finish Buttons Functions
    public void FinishButton()
    {
        if (Main_Controller.currentMenu == Main_Controller.MENU.LEVELFINISH)
        {
            SceneManager.LoadScene(0);
        }
    }

    public bool CheckInternet()
    {
        switch (Application.internetReachability)
        {
            case NetworkReachability.ReachableViaLocalAreaNetwork:
                return true;

            case NetworkReachability.ReachableViaCarrierDataNetwork:
                return false;

            case NetworkReachability.NotReachable:
                return false;

            default:
                return false;
        }

    }
    
}
