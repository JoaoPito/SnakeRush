﻿using UnityEngine;
using System.Collections;

public class Platform_Controller : MonoBehaviour
{
    public enum GENMODE
    {
        NORMAL,
        BUY,
    }

    static public GENMODE currentMode = GENMODE.NORMAL;

    public GameObject actualPlatform;
    public GameObject[] platforms;
    
    private int childsPlatform;
    public byte minDistance;
     
    private int platformIndex;
    private int actualPlatIndex;

    private Vector3 endPos;
    static public int n;

    public Transform player;

    private int bp = 0;
    public GameObject[] buyPlatform;
    static public float buyTime;

    static public GameObject[] scenarioObjs;

    void Awake()
    {
        n = 0;

        platformIndex = 0;
        actualPlatIndex = 0;
    }
    
    void Start()
    {

        if (player == null)
        {
            player = GameObject.FindWithTag("Player").transform;
        }

        actualPlatform = Instantiate(actualPlatform, new Vector3(0, 0, 0), Quaternion.identity) as GameObject;

    }
    
    void Update()
    {
        if (currentMode == GENMODE.NORMAL)
        {

            if (Vector3.Distance(actualPlatform.transform.position, player.position) < minDistance)
            {
                childsPlatform = actualPlatform.transform.childCount;

                for (int i = 0; i < childsPlatform; i++)
                {
                    if (actualPlatform.transform.GetChild(i).CompareTag("End"))
                    {
                        endPos = actualPlatform.transform.GetChild(i).position;
                        break;
                    }
                }

                endPos = actualPlatform.transform.GetChild(0).position;

                LevelInstantiate();
            }

        }else if(currentMode == GENMODE.BUY)
        {
            if (bp <= buyPlatform.Length - 1)
            {
                //buyTime += Time.deltaTime;

                if (Vector3.Distance(actualPlatform.transform.position, player.position) < minDistance+10)
                {
                    childsPlatform = actualPlatform.transform.childCount;

                    for (int i = 0; i < childsPlatform; i++)
                    {
                        if (actualPlatform.transform.GetChild(i).CompareTag("End"))
                        {
                            endPos = actualPlatform.transform.GetChild(i).position;
                            break;
                        }
                    }

                    endPos = actualPlatform.transform.GetChild(0).position;

                    BuyInstantiate(bp);
                }
            }

            if(bp >= buyPlatform.Length)
            {
               //Debug.Log(buyTime.ToString());
            }
        }
        
    }

    void LevelInstantiate()
    {
        while (actualPlatIndex == platformIndex)
        {
            platformIndex = Random.Range(0, platforms.Length - 1);
        }

        actualPlatIndex = platformIndex;

        actualPlatform = Instantiate(platforms[platformIndex], endPos, new Quaternion(0,0,0,0)) as GameObject;
        n++;
        
    }

    void BuyInstantiate(int index)
    {
        actualPlatform = Instantiate(buyPlatform[index], endPos, new Quaternion(0, 0, 0, 0)) as GameObject;
        bp++;
    }

    static public GameObject ReturnDetail()
    {
        if (scenarioObjs != null)
        {
            int i = Random.Range(0, scenarioObjs.Length - 1);

            GameObject dObject = scenarioObjs[i];

            return dObject;
        }
        else
        {
            return null;
        }

    }
    
    }

