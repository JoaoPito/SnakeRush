﻿using UnityEngine;
using System.Collections;

public class Platform_Handler : MonoBehaviour {

    public Transform[] spawners;
    public GameObject point;
    public GameObject[] powers;

    private float randomCollectible;

    private int randomSpawn;

    public byte minDistance = 50;
    private float currentDistance;
    public Transform player;

    private GameObject scenarioObj = null;
    private int childsPlatform;

    private int i;

    void Start()
    {
        i = 0;

        randomSpawn = Random.Range(0, spawners.Length);
        randomCollectible = Random.value*10;

        if (spawners!=null && point!=null) {
            if (powers.Length > 0)
            {
                if (randomCollectible > 1.5f)
                {
                    Instantiate(point, spawners[randomSpawn].position, Quaternion.identity);
                }
                else
                {
                    int randomPwr = Random.Range(0, powers.Length);
                    Instantiate(powers[randomPwr], spawners[randomSpawn].position, Quaternion.identity);
                }
            }
            else
            {
                Instantiate(point, spawners[randomSpawn].position, Quaternion.identity);
            }

        }

        player = GameObject.FindWithTag("Player").transform;

        childsPlatform = transform.childCount;

    }

    void Update()
    {
        currentDistance = player.position.z - transform.position.z;

        if (i < childsPlatform && Platform_Controller.currentMode == Platform_Controller.GENMODE.NORMAL)
        {
            InstantiateDetail();
            i++;
        }

        if (currentDistance > minDistance)
        {
            Destroy(gameObject);
        }
    }

    void InstantiateDetail()
    {
        scenarioObj = Platform_Controller.ReturnDetail();

        if (scenarioObj != null)
        {
           if (transform.GetChild(i).CompareTag("DetailSpawn"))
           {
               Instantiate(scenarioObj, transform.GetChild(i).position, Quaternion.identity);
           }
        }

    }
}
