﻿using UnityEngine;

public class ObjectDestroyer : MonoBehaviour {

    public float destroyDistance = 40;
    private Transform player;
    
	void Start () {

        player = GameObject.FindWithTag("Player").GetComponent<Transform>();
        
	}
    void Update() {
        if (player.position.z - transform.position.z>destroyDistance)
        {
            Destroy(gameObject);
        }
    }
}
