
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class Shop_Controller : MonoBehaviour
{
    public enum MENUS
    {
        MAIN,
        SKINS,
        LEVELS
    }

    public MENUS currentShopMenu;

    private Vector2 fingerStartPos;
    private float fingerStartTime;
    private bool isSwipe;
    private Touch touch;

    //Scripts
    public Point_Controller pointsScr;
    public ChangeSkins_Controller skinsScr;

    public Platform_Controller platScr;

    //Index
    public int selectedIndex;
    private int maxIndex;

    public int currentSkinIndex;

    //Shop GUI
    public GameObject ShopCanvas;

    public GameObject skinStartButton;
    public GameObject levelStartButton;

    //Skin GUI
    public GameObject skinButtonObj;
    public Button skinButton;
    public Image skinImg;
    public Text skinName;
    public Text skinBuy;
    public Image SkinPow;

    public bool setting;

    public Sprite[] skinPowImgs;

    //Level GUI
    public GameObject levelButtonObj;
    public Button levelButton;
    public Text levelName;
    public Text levelBuy;
    public Text levelTime;
    public Text levelPoints;

    static public bool setted;

    public GameObject background;

    void Start()
    {
        
        ShopCanvas.SetActive(true);

        setted = false;

        switch (currentShopMenu)
        {
            case MENUS.MAIN:

                skinStartButton.SetActive(true);

                levelStartButton.SetActive(true);

                skinButtonObj.SetActive(false);

                break;

            case MENUS.SKINS:

                maxIndex = skinsScr.skins.Length - 1;

                currentSkinIndex = PlayerPrefs.GetInt("currentPlayerSkin");
                selectedIndex = currentSkinIndex;

                GetSkin();

                break;

            case MENUS.LEVELS:

                maxIndex = skinsScr.levels.Length - 1;

                currentSkinIndex = PlayerPrefs.GetInt("currentLevel");
                selectedIndex = currentSkinIndex;

                GetLevel();

                break;
        }
        

    }

    void Update()
    {

        //Debug.Log(currentShopMenu);
        Main_Controller.currentMenu = Main_Controller.MENU.SHOP;

        switch (currentShopMenu)
        {
            case MENUS.MAIN:

                skinStartButton.SetActive(true);

                levelStartButton.SetActive(true);

                setting = false;

                break;

            case MENUS.SKINS:

                if (!setting)
                {
                    maxIndex = skinsScr.skins.Length - 1;

                    currentSkinIndex = PlayerPrefs.GetInt("currentPlayerSkin");
                    selectedIndex = currentSkinIndex;

                    GetSkin();

                    setting = true;
                }

                break;

            case MENUS.LEVELS:

                if (!setting)
                {
                    maxIndex = skinsScr.levels.Length - 1;

                    currentSkinIndex = PlayerPrefs.GetInt("currentLevel");
                    selectedIndex = currentSkinIndex;

                    GetLevel();

                    setting = true;
                }

                break;
        }

        TouchGesture();
    }

    public void GetSkin()
    {
        skinsScr.skins[selectedIndex].buy = skinsScr.LoadSkin(selectedIndex);

        skinImg.sprite = skinsScr.skins[selectedIndex].skinImg;
        skinName.text = skinsScr.skins[selectedIndex].skinName;
        
        switch (skinsScr.skins[selectedIndex].skinPower)
        {
            case ChangeSkins_Controller.Powers.NONE:
                SkinPow.sprite = skinPowImgs[0];
                break;

            case ChangeSkins_Controller.Powers.FAST:
                SkinPow.sprite = skinPowImgs[1];
                break;

            case ChangeSkins_Controller.Powers.INVISIBLE:
                SkinPow.sprite = skinPowImgs[2];
                break;
        }

        if (skinsScr.skins[selectedIndex].buy || skinsScr.skins[selectedIndex].skinValue <= 0)
        {
            if (selectedIndex != currentSkinIndex)
            {
                skinBuy.text = "Use Skin";
            }
        }
        else
        {
            skinBuy.text = string.Concat(skinsScr.skins[selectedIndex].skinValue.ToString()," points");
        }

        if (selectedIndex == currentSkinIndex)
        {
            skinBuy.text = "Using";
        }
        
    }

    public void BuySkin()
    {
        if(pointsScr.currentPoints>= skinsScr.skins[selectedIndex].skinValue)
        {
            pointsScr.currentPoints -= skinsScr.skins[selectedIndex].skinValue;
            skinsScr.skins[selectedIndex].buy = true;
            skinsScr.SaveSkin(selectedIndex, true);
            skinsScr.ChangeSkin(selectedIndex);

            currentSkinIndex = selectedIndex;

            pointsScr.SavePoints();
        }
        GetSkin();
    }


    public void GetLevel()
    {
        skinsScr.levels[selectedIndex].buy = skinsScr.LoadLevel(selectedIndex);
        
        levelName.text = skinsScr.levels[selectedIndex].levelName;

        if (PlayerPrefs.GetInt(string.Concat("Level", selectedIndex.ToString(), "_Time_Sec")) == 0 && PlayerPrefs.GetInt(string.Concat("Level", selectedIndex.ToString(), "_Time_Min")) == 0)
        {
            levelTime.text = string.Concat(skinsScr.levels[selectedIndex].defaultFinishTimeMin.ToString(), "' ", skinsScr.levels[selectedIndex].defaultFinishTimeSec.ToString(), "''");
        }
        else
        {
            levelTime.text = string.Concat(PlayerPrefs.GetInt(string.Concat("Level", selectedIndex.ToString(), "_Time_Min")), "' ", PlayerPrefs.GetInt(string.Concat("Level", selectedIndex.ToString(), "_Time_Sec")), "''");
        }

        levelPoints.text = skinsScr.levels[selectedIndex].rewardPoints.ToString();

        PlayerPrefs.SetInt("CurrentLevel",selectedIndex);

        if (skinsScr.levels[selectedIndex].buy || skinsScr.levels[selectedIndex].levelValue <= 0)
        {
            if (selectedIndex != currentSkinIndex)
            {
                levelBuy.text = "Use Level";
            }
        }
        else
        {
            levelBuy.text = string.Concat(skinsScr.levels[selectedIndex].levelValue.ToString(), " points");
        }

        if (selectedIndex == currentSkinIndex)
        {
            levelBuy.text = "Using";
        }
    }

    public void BuyLevel()
    {
        if (pointsScr.currentPoints >= skinsScr.levels[selectedIndex].levelValue)
        {
            pointsScr.currentPoints -= skinsScr.levels[selectedIndex].levelValue;
            skinsScr.levels[selectedIndex].buy = true;
            skinsScr.SaveLevel(selectedIndex, true);
            skinsScr.SetLevel(selectedIndex);

            currentSkinIndex = selectedIndex;

            pointsScr.SavePoints();
        }
        GetLevel();
    }

    //Skin/Level Button Activating
    public void SkinActivate()
    {
        currentShopMenu = MENUS.SKINS;

        skinButtonObj.SetActive(true);
    }

    public void LevelActivate()
    {
        currentShopMenu = MENUS.LEVELS;

        levelButtonObj.SetActive(true);
    }

    

    //GUI Functions
    public void useSkinButton()
    {
        if (skinsScr.skins[selectedIndex].buy || skinsScr.skins[selectedIndex].skinValue <= 0)
        {
            currentSkinIndex = selectedIndex;
            skinsScr.ChangeSkin(selectedIndex);
            
            skinBuy.text = "Using";
        }
        else
        {
            BuySkin();
        }
    }

    public void useLevelButton()
    {
        if (skinsScr.levels[selectedIndex].buy || skinsScr.levels[selectedIndex].levelValue <= 0)
        {
            currentSkinIndex = selectedIndex;
            skinsScr.SetLevel(selectedIndex);

            levelBuy.text = "Using";
        }
        else
        {
            BuyLevel();
        }
    }

    public void SkinGUIAnim()
    {
        skinButtonObj.GetComponent<EasyTween>().OpenCloseObjectAnimation();
    }

    public void LevelGUIAnim()
    {
        levelButtonObj.GetComponent<EasyTween>().OpenCloseObjectAnimation();
    }

    public void Exit()
    {
        switch (currentShopMenu)
        {
            case MENUS.MAIN:
                
                Main_Controller.currentMenu = Main_Controller.MENU.MAINMENU;

                currentShopMenu = MENUS.MAIN;

                if (setted)
                    SceneManager.LoadScene(0);
                break;

            case MENUS.SKINS:
                currentShopMenu = MENUS.MAIN;
                skinButtonObj.GetComponent<EasyTween>().OpenCloseObjectAnimation();
                break;

            case MENUS.LEVELS:
                currentShopMenu = MENUS.MAIN;
                levelButtonObj.GetComponent<EasyTween>().OpenCloseObjectAnimation();
                break;

        }
    }

    void TouchGesture()
    {
        if (!Application.isEditor)
        {
            touch = Input.GetTouch(0);
            switch (touch.phase)
            {
                case TouchPhase.Began:
                    isSwipe = true;
                    fingerStartTime = Time.time;
                    fingerStartPos = touch.position;
                    break;
                case TouchPhase.Canceled:
                    isSwipe = false;
                    break;
                case TouchPhase.Ended:

                    float gestureTime = Time.time - fingerStartTime;
                    float gestureDist = (touch.position - fingerStartPos).magnitude;

                    if (isSwipe && gestureTime < 0.5 && gestureDist > 50)
                    {
                        Vector2 direction = touch.position - fingerStartPos;

                        if (Mathf.Abs(direction.x) > Mathf.Abs(direction.y) && direction.x > 0 && selectedIndex > 0)
                        {
                            selectedIndex--;
                            if (currentShopMenu == MENUS.SKINS) {
                                GetSkin();
                            }
                            else if (currentShopMenu == MENUS.LEVELS)
                            {
                                GetLevel();
                            }

                        }
                        else if (Mathf.Abs(direction.x) > Mathf.Abs(direction.y) && direction.x < 0 && selectedIndex < maxIndex)
                        {
                            selectedIndex++;
                            if (currentShopMenu == MENUS.SKINS)
                            {
                                GetSkin();
                            }else if (currentShopMenu == MENUS.LEVELS)
                            {
                                GetLevel();
                            }
                        }


                    }
                    break;

            }

        }
        else
        {
            if (Input.GetKeyDown("d") && selectedIndex < maxIndex)
            {
                selectedIndex++;
                if (currentShopMenu == MENUS.SKINS)
                {
                    GetSkin();
                }
                else if (currentShopMenu == MENUS.LEVELS)
                {
                    GetLevel();
                }
            }
            else if (Input.GetKeyDown("a") && selectedIndex > 0)
            {
                selectedIndex--;
                if (currentShopMenu == MENUS.SKINS)
                {
                    GetSkin();
                }
                else if (currentShopMenu == MENUS.LEVELS)
                {
                    GetLevel();
                }
            }
        }

    }
}
