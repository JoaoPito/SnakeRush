﻿using UnityEngine;
using System.Collections;

public class Challenges_Controller : MonoBehaviour {

    public enum ClgFunction
    {
        DISTANCE,
        TIME,
        POINTS,

    }

    [System.Serializable]
    public class Challenge
    {
        public ClgFunction objective;
        public int reward;
        public string description;
    }

    public Challenge[] challenges;

    // Use this for initialization
    void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
