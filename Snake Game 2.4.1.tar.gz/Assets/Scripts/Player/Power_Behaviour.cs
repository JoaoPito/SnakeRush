﻿using UnityEngine;
using System.Collections;

public class Power_Behaviour : MonoBehaviour {

    private Transform player;
    private Vector2 playerDistance;
    public float minDistance;
    public byte spinSpeed;

    public ChangeSkins_Controller.Powers power;
    public float pwIntensity;
    public float pwTime;

    // Use this for initialization
    void Start () {
        player = GameObject.FindWithTag("Player").transform;
    }
	
	// Update is called once per frame
	void Update () {

        transform.Rotate(0, spinSpeed * Time.deltaTime, 0);

        playerDistance = new Vector2(transform.position.x - player.position.x, transform.position.z - player.position.z);
        
            if ((playerDistance.x < minDistance && playerDistance.x > -minDistance) && (playerDistance.y < minDistance && playerDistance.y > -minDistance))
            {
                Destroy(gameObject);

                if (ChangeSkins_Controller.pwFunctionActivate)
                {
                    ChangeSkins_Controller.currentPowerTime = 0;
                }
                else
                {
                    ChangeSkins_Controller.currentPower = power;
                    ChangeSkins_Controller.currentPwIntensity = pwIntensity;
                    ChangeSkins_Controller.currentPwTime = pwTime;

                    ChangeSkins_Controller.pwFunctionActivate = true;
                }
            }

        //Distance Destroy
        if (transform.position.z - player.position.z < -25)
        {
            Destroy(gameObject);
        }

    }
    
}
