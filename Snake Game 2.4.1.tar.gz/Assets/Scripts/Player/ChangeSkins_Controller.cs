﻿using UnityEngine;

public class ChangeSkins_Controller : MonoBehaviour {

    public enum Powers
    {
        NONE,
        FAST,
        INVISIBLE,
        JUMP,
        POINTS,
    }

    public enum Scenario
    {
        NORMAL,
        TREE,
        DESERT,
        SEA,
        GOLD,
        BLOCKS,

    }

    [System.Serializable]
    public class Skin
    {
        public string skinName;
        public int skinValue;

        public Scenario skinScenario;

        public bool buy = false;

        public Sprite skinImg;

        public GameObject SkinGraphic;
        public GameObject playerTail;

        public float tailUpdateTime;
        
        public float WalkSpeed;
        public float speedGain;

        public Powers skinPower;
        public float PowerTime;
        public float PowerIntensity;
    }

    [System.Serializable]
    public class Level
    {
        public string levelName;
        public int levelValue;

        public int defaultFinishTimeMin;
        public int defaultFinishTimeSec;

        public int rewardPoints;

        public bool buy = false;

        public GameObject[] levelPlatforms;
    }

    public Skin[] skins;

    public Level[] levels;

    public Player_Movement playerscript;
    public Main_Controller mainController;

    public Transform Player;
    public GameObject playerGraphic;

    private int currentSkinIndex;

    //Skins Details
    public GameObject[] treeBkgDetail;
    public GameObject[] desertBkgDetail;
    public GameObject[] goldBkgDetail;

    //Powers variables
    static public float currentPowerTime;
    static public bool pwFunctionActivate;
    static public bool pwActivated;

    private byte fi = 0;

    //Power Get Variables
    static public Powers currentPower = Powers.NONE;
    static public float currentPwIntensity;
    static public float currentPwTime;

    //Skins Power Variables
    public float pwrCoolDownTime;
    public float maxCoolDown = 10;
    private bool inPower;

    //Level Platform Variables
    public Platform_Controller platScr;
    private int currentLevelIndex;

    private Color lastColor;

    void Start () {

        currentPower = Powers.NONE;
        currentPwIntensity = 0;
        currentPwTime = 0;

        currentSkinIndex = PlayerPrefs.GetInt("currentPlayerSkin");
        currentLevelIndex = PlayerPrefs.GetInt("currentLevel");

        playerGraphic = GameObject.FindWithTag("Player_Graphic");

        ChangeSkin(currentSkinIndex);

        SetLevel(currentLevelIndex);

        if (mainController == null)
        {
            mainController = transform.GetComponent<Main_Controller>();
        }

    }
	
	void Update () {

        if (Main_Controller.currentMenu == Main_Controller.MENU.PLAY)
        {
            if ((MultipleTap(2)||Input.GetKeyUp("r")) && pwrCoolDownTime>=maxCoolDown)
            {
                SkinPower();
                pwrCoolDownTime = 0;
            }

            if (pwrCoolDownTime < maxCoolDown)
            {
                pwrCoolDownTime += Time.deltaTime;

                if (pwActivated)
                {
                    mainController.sideMat.color = Color.Lerp(mainController.sideMat.color, Color.yellow, 20 * Time.deltaTime);
                }
                else
                {
                    mainController.sideMat.color = Color.Lerp(mainController.sideMat.color, lastColor,  Time.deltaTime);
                }
            }

            if (pwFunctionActivate)
            {
                ActivatePower(currentPower, currentPwTime, currentPwIntensity);
            }

            

        }
    }
    
    //Change Player Values
    public void ChangeAtributes(float WalkSpeed, float speedGain, float updateTime)
    {
        playerscript.walkSpeed = WalkSpeed;
        playerscript.speedGain = speedGain;


        if (updateTime > 0)
        {
            playerscript.timeWalk = updateTime;
        }

        Shop_Controller.setted = true;
    }

    public void ChangeGraphic(GameObject headGraphic, GameObject tailPrefab)
    {
        Transform oldGraphic = GameObject.FindWithTag("Player_Graphic").transform;

        playerscript.tailPrefab = tailPrefab;

        playerGraphic = Instantiate(headGraphic, oldGraphic.position, oldGraphic.rotation) as GameObject;
        Destroy(oldGraphic.gameObject);

        playerGraphic.transform.SetParent(Player);

        playerscript.headGraphic = playerGraphic.transform;

    }

    public void ChangeSkin(int index)
    {
        if (PlayerPrefs.GetInt(string.Concat("PlayerSkin_", index.ToString(), "_bought")) > 0 || skins[index].skinValue <= 0)
        {
            skins[index].buy = true;

            currentSkinIndex = index;

            ChangeGraphic(skins[index].SkinGraphic, skins[index].playerTail);
            ChangeAtributes(skins[index].WalkSpeed, skins[index].speedGain, skins[index].tailUpdateTime);

            PlayerPrefs.SetInt("currentPlayerSkin", index);

            ChangeScenario(index);

            Shop_Controller.setted = true;
        }
    }

    //Platforms Level Set
    public void SetLevel(int index)
    {
        if (index > 0)
        {
            platScr.buyPlatform = levels[index].levelPlatforms;
            Platform_Controller.currentMode = Platform_Controller.GENMODE.BUY;

            if (PlayerPrefs.GetInt(string.Concat("Level", index.ToString(), "_Time_Sec")) == 0 && PlayerPrefs.GetInt(string.Concat("Level", index.ToString(), "_Time_Min")) == 0)
            {
                Point_Controller.TimeMin = levels[index].defaultFinishTimeMin;
                Point_Controller.TimeSec = levels[index].defaultFinishTimeSec;
            }
            else
            {
                Point_Controller.TimeMin = PlayerPrefs.GetInt(string.Concat("Level", index.ToString(), "_Time_Min"));
                Point_Controller.TimeSec = PlayerPrefs.GetInt(string.Concat("Level", index.ToString(), "_Time_Sec"));
            }
        }
        else
        {
            Platform_Controller.currentMode = Platform_Controller.GENMODE.NORMAL;
            platScr.buyPlatform = null;
        }

        PlayerPrefs.SetInt("currentLevel", index);

        Shop_Controller.setted = true;
    }

    public void ChangeScenario(int index)
    {
        if (PlayerPrefs.GetInt(string.Concat("PlayerSkin_", index.ToString(), "_bought")) > 0 || skins[index].skinValue <= 0) {
            switch (skins[index].skinScenario)
            {
                case Scenario.NORMAL:
                    Platform_Controller.scenarioObjs = null;
                break;

                case Scenario.TREE:
                    Platform_Controller.scenarioObjs = treeBkgDetail;
                    break;

                case Scenario.DESERT:
                    Platform_Controller.scenarioObjs = desertBkgDetail;
                    break;

                case Scenario.GOLD:
                    Platform_Controller.scenarioObjs = goldBkgDetail;
                    break;
            }
        }
    }
    
    //Save&Load Skin buy state
    public void SaveSkin(int index,bool value)
    {
        if (value)
        {
            PlayerPrefs.SetInt(string.Concat("PlayerSkin_", index.ToString(), "_bought"), 1);
        }
        else
        {
            PlayerPrefs.SetInt(string.Concat("PlayerSkin_", index.ToString(), "_bought"), 0);
        }
    }

    public bool LoadSkin(int index)
    {
        if (PlayerPrefs.GetInt(string.Concat("PlayerSkin_", index.ToString(), "_bought")) > 0 || skins[index].skinValue <= 0)
        {
            return true;
        }
        else
        {
            return false;
        }
    }

    //Save&Load Level buy state
    public void SaveLevel(int index, bool value)
    {
        if (value)
        {
            PlayerPrefs.SetInt(string.Concat("Level_", index.ToString(), "_bought"), 1);
        }
        else
        {
            PlayerPrefs.SetInt(string.Concat("Level_", index.ToString(), "_bought"), 0);
        }
    }

    public bool LoadLevel(int index)
    {
        if (PlayerPrefs.GetInt(string.Concat("Level_", index.ToString(), "_bought")) > 0 || skins[index].skinValue <= 0)
        {
            return true;
        }
        else
        {
            return false;
        }
    }

    //Skin Powers
    public void SkinPower()
    {
        currentSkinIndex = PlayerPrefs.GetInt("currentPlayerSkin");
        

        if (skins[currentSkinIndex].skinPower != Powers.NONE)
        {
            currentPower = skins[currentSkinIndex].skinPower;
            currentPwTime = skins[currentSkinIndex].PowerTime;
            currentPwIntensity = skins[currentSkinIndex].PowerIntensity;

            pwFunctionActivate = true;
        }
    }

    //Power Atributes
    public void ActivatePower(Powers power, float maxTime, float intensity)
    {
        
        if (currentPowerTime < maxTime)
            currentPowerTime += Time.deltaTime;

        switch (power)
        {
            case Powers.FAST:
                
                if (currentPowerTime < maxTime)
                {
                    if (!pwActivated)
                    {
                        FastPower(intensity,false);
                        pwActivated = true;

                        lastColor = mainController.sideMat.color;
                    }
                }
                else
                {
                    if (pwActivated)
                    {
                        FastPower(intensity, true);
                        pwActivated = false;
                        currentPowerTime = 0;
                        pwFunctionActivate = false;
                    }
                }
                break;

            case Powers.INVISIBLE:
                JumpPower(0);
                break;

            case Powers.JUMP:
                InvisiblePower();
                break;

            case Powers.POINTS:
                if (fi< Mathf.Round(currentPwIntensity))
                {
                    GainPoints(Mathf.FloorToInt(currentPwIntensity));
                    fi++;
                }
                break;
        }
    }

    public void FastPower(float intensity,bool deactivate)
    {

        if (!deactivate)
        {
            playerscript.walkSpeed += intensity;
            playerscript.timeWalk -= intensity/200;
        }
        else
        {
            playerscript.walkSpeed -= intensity;
            playerscript.timeWalk += intensity / 200;
        }
    }

    public void JumpPower(int jumpTimes)  
    {

    }

    public void InvisiblePower()
    {

    }

    public void GainPoints(int points)
    {
        playerscript.eat = true;
        Point_Controller.levelPoints++;
        pwActivated = true;
        playerscript.TailMovement();
    }

    //Screen Controls
    public bool MultipleTap(int times)
    {
        if (!Application.isEditor)
        {
            bool touched = false;
            Touch touch = Input.GetTouch(0);
            if (Input.touchCount == 1)
            {
                if (touch.phase == TouchPhase.Ended)
                {
                    if (touch.tapCount == times)
                    {
                        touched = true;
                    }
                }
            }
            return touched;
        }
        else
        {
            return false;
        }
    }
}
