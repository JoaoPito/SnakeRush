﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System.Linq;

public class Player_Movement : MonoBehaviour {

	 public enum PLAYERDIRECTION{
		UP,
		DOWN,
		RIGHT,
		LEFT,
		STOP,
	}

	private Vector2 fingerStartPos;
	private float fingerStartTime;
	private bool isSwipe; 
	private Touch touch;

	static public PLAYERDIRECTION currentDirection = PLAYERDIRECTION.STOP;

	public Transform headGraphic;
	public Rigidbody playerRigidbody;
	public float walkSpeed;
	public float timeWalk;
    private float repeatMovement;

    public float speedGain;
    static public bool gainSpeed;

    private Vector3 direction;
    public float raycastDis;
    private RaycastHit rayInfo;

    public GameObject tailPrefab;

    public bool eat = true;
    List<Transform> tail = new List<Transform>();

    private GameObject g;

    public int playerDistance;
    
    private bool dead = false;
    
    public Collision frontCollider;
    public Transform raycastOrigin;

    public GameObject Ee1;

    public Animator skinAnim;

    void Start () {

        TailMovement();

        currentDirection = PLAYERDIRECTION.STOP;

		if (playerRigidbody == null) {
			playerRigidbody = transform.GetComponent<Rigidbody>();
		}

        skinAnim = GetComponentInChildren<Animator>();
        
	}
	
	void Update () {
        
        repeatMovement += Time.deltaTime;
        if (repeatMovement > timeWalk)
        {
            Movement();
            TailMovement();
            repeatMovement = 0;
        }

        if (skinAnim != null)
        {
            if (currentDirection == PLAYERDIRECTION.STOP)
            {
                skinAnim.SetBool("Walking", false);
            }
            else
            {
                skinAnim.SetBool("Walking", true);
            }
        }

        if (Main_Controller.currentMenu == Main_Controller.MENU.PLAY)
        {

            if (dead)
            {
                Main_Controller.currentMenu = Main_Controller.MENU.LOSE;
            }

            if (timeWalk <= 0.0001f)
            {
                timeWalk = 0.0001f;
            }

            //Distance Control
            if (currentDirection == PLAYERDIRECTION.UP && transform.position.z / 1.5f >= playerDistance)
                playerDistance = Mathf.FloorToInt(transform.position.z / 1.5f);

            if (playerDistance>19999)
            {
                Ee1.SetActive(true);
            }

            if (Physics.Raycast(raycastOrigin.position,headGraphic.forward,out rayInfo,raycastDis))
            {
                if (rayInfo.transform.CompareTag("PlayerTail"))
                {
                    dead = true;
                }

                if (rayInfo.transform.CompareTag("Finish"))
                {
                    Point_Controller.timeCount = false;
                    Main_Controller.currentMenu = Main_Controller.MENU.LEVELFINISH;
                }
            }


            //Touch Controls
            if (Input.touchCount > 0)
            {
                TouchGesture();
            }

            if (Input.GetKeyUp("d") && currentDirection != PLAYERDIRECTION.LEFT)
            {
                currentDirection = PLAYERDIRECTION.RIGHT;
            }
            if (Input.GetKeyUp("a") && currentDirection != PLAYERDIRECTION.RIGHT)
            {
                currentDirection = PLAYERDIRECTION.LEFT;
            }
            if (Input.GetKeyUp("s") && currentDirection != PLAYERDIRECTION.UP)
            {
                currentDirection = PLAYERDIRECTION.DOWN;
            }
            if (Input.GetKeyUp("w") && currentDirection != PLAYERDIRECTION.DOWN)
            {
                currentDirection = PLAYERDIRECTION.UP;
            }

            //Direction Control
            switch (currentDirection)
            {

                case PLAYERDIRECTION.UP:
                    direction = new Vector3(0, playerRigidbody.velocity.y, walkSpeed);
                    break;

                case PLAYERDIRECTION.DOWN:
                    direction = new Vector3(0, playerRigidbody.velocity.y, -walkSpeed);
                    break;

                case PLAYERDIRECTION.RIGHT:
                    direction = new Vector3(walkSpeed, playerRigidbody.velocity.y, 0);
                    break;

                case PLAYERDIRECTION.LEFT:
                    direction = new Vector3(-walkSpeed, playerRigidbody.velocity.y, 0);
                    break;

                case PLAYERDIRECTION.STOP:
                    direction = new Vector3(0, 0, 0);
                    break;

            }

            //Speed Gain
            if (gainSpeed)
            {
                timeWalk -= speedGain*0.02f;
                walkSpeed += speedGain;
                gainSpeed = false;
            }

            //Time Rush
            if (Platform_Controller.currentMode == Platform_Controller.GENMODE.BUY)
            {
                if (transform.position.z > 2 && transform.position.z < 3) {
                    Point_Controller.timeCount = true;
                }

                if (Point_Controller.timeOut)
                {
                    dead = true;
                }
            }

        }
        else
        {
            currentDirection = PLAYERDIRECTION.STOP;
        }

    }
    
	public void Movement(){

        if (Main_Controller.currentMenu == Main_Controller.MENU.PLAY)
        {
            playerRigidbody.velocity = direction;
            
            switch (currentDirection)
            {

                case PLAYERDIRECTION.UP:
                    headGraphic.eulerAngles = new Vector3(0, 0, 0);
                    break;

                case PLAYERDIRECTION.DOWN:
                    headGraphic.eulerAngles = new Vector3(0, 180, 0);
                    break;

                case PLAYERDIRECTION.RIGHT:
                    headGraphic.eulerAngles = new Vector3(0, 90, 0);
                    break;

                case PLAYERDIRECTION.LEFT:
                    headGraphic.eulerAngles = new Vector3(0, 270, 0);
                    break;

            }

        }
        else
        {
            playerRigidbody.velocity = Vector3.zero;
        }
        

    }

    public void TailMovement()
    {
        if (Main_Controller.currentMenu == Main_Controller.MENU.PLAY)
        {
            Vector3 ta = transform.position;
            Quaternion ra = headGraphic.rotation;

            if (eat)
            {
                timeWalk -= speedGain * 0.02f;
                walkSpeed += speedGain;
                if (tailPrefab != null)
                {
                    g = (GameObject)Instantiate(tailPrefab, ta, ra);
                    tail.Insert(0, g.transform);
                }
                eat = false;
            }
            else if (tail.Count > 0)
            {
                tail.Last<Transform>().position = ta;
                tail.Last<Transform>().rotation = ra;
                tail.Insert(0, tail.Last<Transform>());
                tail.RemoveAt(tail.Count - 1);

            }

        }
    }

    void TouchGesture()
    {

            touch = Input.GetTouch(0);
            switch (touch.phase)
            {
                case TouchPhase.Began:
                    isSwipe = true;
                    fingerStartTime = Time.time;
                    fingerStartPos = touch.position;
                    break;
                case TouchPhase.Canceled:
                    isSwipe = false;
                    break;
                case TouchPhase.Ended:

                    float gestureTime = Time.time - fingerStartTime;
                    float gestureDist = (touch.position - fingerStartPos).magnitude;

                    if (isSwipe && gestureTime < 0.5 && gestureDist > 50)
                    {
                        Vector2 direction = touch.position - fingerStartPos;

                        if (Mathf.Abs(direction.x) > Mathf.Abs(direction.y) && direction.x > 0 && currentDirection != PLAYERDIRECTION.LEFT)
                        {
                            currentDirection = PLAYERDIRECTION.RIGHT;

                        }
                        else if (Mathf.Abs(direction.x) > Mathf.Abs(direction.y) && direction.x < 0 && currentDirection != PLAYERDIRECTION.RIGHT)
                        {
                            currentDirection = PLAYERDIRECTION.LEFT;

                        }

                        else if (Mathf.Abs(direction.x) < Mathf.Abs(direction.y) && direction.y < 0 && currentDirection != PLAYERDIRECTION.UP)
                        {
                            currentDirection = PLAYERDIRECTION.DOWN;

                        }
                        else if (Mathf.Abs(direction.x) < Mathf.Abs(direction.y) && direction.y > 0 && currentDirection != PLAYERDIRECTION.DOWN)
                    {
                            currentDirection = PLAYERDIRECTION.UP;
                        }
                    }
                    break;
            
        }

    }

    void OnCollisionEnter(Collision frontCol)
    {
        if (frontCol.transform.CompareTag("Platform"))
        {
            dead = true;
        }
    }
    
}
