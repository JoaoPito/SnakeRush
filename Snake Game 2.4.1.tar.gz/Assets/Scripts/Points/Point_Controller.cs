﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class Point_Controller : MonoBehaviour {
    
    public int currentPoints;
    static public int levelPoints;
    public Text pointsText;
    
    public Text distanceText;
    public Text levelTimeText;
    public Text levelBestTimeText;

    public Player_Movement playerScr;

    public Shop_Controller shopScr;
    public ChangeSkins_Controller levelScr;

    public int bestDistance;

    public Text recordText;

    //Time Platform Variables
    static public bool timeCount;
    static public bool timeOut;

    static public float TimeSec;
    static public int TimeMin;

    private int bestTimeSec;
    private int bestTimeMin;

    private float levelTimeSec;
    private int levelTimeMin;

    private int currentLevelPoints;
    
	void Start () {

        timeCount = false;
        timeOut = false;

        bestTimeMin = TimeMin;
        bestTimeSec = Mathf.RoundToInt(TimeSec);

        currentPoints = LoadPoints();

        bestDistance = LoadDistance();

        currentLevelPoints = levelScr.levels[PlayerPrefs.GetInt("CurrentLevel")].rewardPoints;

    }
	
	void Update () {

        if(recordText.enabled == false && recordText.text != null)
        {
            if (Platform_Controller.currentMode == Platform_Controller.GENMODE.NORMAL)
            {
                if (bestDistance >= 10 && Platform_Controller.currentMode == Platform_Controller.GENMODE.NORMAL)
                {
                    recordText.enabled = true;
                    recordText.text = "Best Distance";
                    recordText.rectTransform.position = new Vector3(recordText.rectTransform.position.x, recordText.rectTransform.position.y, bestDistance * 1.5f);
                }
            }
            else
            {
                recordText.text = null;
                recordText.enabled = false;
            }
        }
                
        if (Main_Controller.currentMenu == Main_Controller.MENU.PLAY || Main_Controller.currentMenu == Main_Controller.MENU.LOSE || Main_Controller.currentMenu == Main_Controller.MENU.LEVELFINISH || Main_Controller.currentMenu == Main_Controller.MENU.PAUSE)
        {
            if (Platform_Controller.currentMode == Platform_Controller.GENMODE.NORMAL)
            {
                distanceText.text = playerScr.playerDistance.ToString();

                if (Main_Controller.currentMenu == Main_Controller.MENU.PLAY)
                {
                    pointsText.text = levelPoints.ToString();
                }
            }
            else if(Platform_Controller.currentMode == Platform_Controller.GENMODE.BUY)
            {
                if (Main_Controller.currentMenu == Main_Controller.MENU.PLAY)
                {

                    if (timeCount)
                    {
                        if (TimeSec > 0.4)
                        {
                            TimeSec -= Time.deltaTime;
                            levelTimeSec += Time.deltaTime;
                            if (levelTimeSec >= 60)
                            {
                                levelTimeMin++;
                                levelTimeSec = 0;
                            }
                        }
                        else if (TimeMin > 0)
                        {
                            TimeMin --;
                            TimeSec = 59;
                        }                        

                        if (TimeMin <= 0 && TimeSec<=11)
                        {
                            distanceText.color = Color.Lerp(distanceText.color, Color.red, 2*Time.deltaTime);
                        }

                    }

                    if (TimeSec<0.5f && TimeMin == 0)
                    {
                        timeCount = false;
                        timeOut = true;
                    }
                    else
                    {
                        timeOut = false;
                    }

                    pointsText.text = levelPoints.ToString();

                }

                distanceText.text = string.Concat(TimeMin.ToString(), "' ", Mathf.RoundToInt(TimeSec).ToString(), "''");
            }

            if (Main_Controller.currentMenu == Main_Controller.MENU.LEVELFINISH)
            {   
                levelTimeText.text = string.Concat(levelTimeMin.ToString(), "' ", Mathf.RoundToInt(levelTimeSec).ToString(), "''");
                levelBestTimeText.text = string.Concat(bestTimeMin.ToString(), "' ", bestTimeSec.ToString(), "''");
                
                if ((levelTimeMin <= bestTimeMin) && (levelTimeSec < bestTimeSec))
                    SaveLevelTime();

                if (levelPoints < levelPoints + levelScr.levels[PlayerPrefs.GetInt("CurrentLevel")].rewardPoints)
                {
                    levelPoints += currentLevelPoints;
                }
                    currentLevelPoints = 0;
                

                if (currentPoints < currentPoints + levelPoints)
                {
                    pointsText.text = levelPoints.ToString();
                    currentPoints += levelPoints;
                    SavePoints();
                    levelPoints = 0;
                }
                    
            }
            
        }
        else
        {
            if (Platform_Controller.currentMode == Platform_Controller.GENMODE.NORMAL)
            {
                distanceText.text = bestDistance.ToString();
            }
            else
            {
                distanceText.text = string.Concat(TimeMin.ToString(), "' ", Mathf.RoundToInt(TimeSec).ToString(), "''");
            }

            pointsText.text = currentPoints.ToString();
        }

        if (Main_Controller.currentMenu == Main_Controller.MENU.LOSE)
        {

            SaveDistance();

            if (currentPoints < currentPoints + levelPoints)
            {
                pointsText.text = levelPoints.ToString();
                currentPoints += levelPoints;
                SavePoints();
                levelPoints = 0;
            }
            
         }

        
    }

    public void SavePoints()
    {
        PlayerPrefs.SetInt("PlayerPoints", currentPoints);
    }

    public int LoadPoints()
    {
        int points;
        points = PlayerPrefs.GetInt("PlayerPoints");
        return (points);
    }

    public void ClearPoints()
    {
        PlayerPrefs.DeleteKey("PlayerPoints");
    }


    public void SaveDistance()
    {
        if(playerScr.playerDistance> bestDistance)
        {
            PlayerPrefs.SetInt("PlayerDistance", playerScr.playerDistance);
        }

    }

    public int LoadDistance()
    {
        int dis;
        dis = PlayerPrefs.GetInt("PlayerDistance");
        return (dis);
    }

    public void DeleteDistance()
    {
        PlayerPrefs.DeleteKey("PlayerDistance");
    }

    public void SaveLevelTime()
    {
        PlayerPrefs.SetInt(string.Concat("Level", PlayerPrefs.GetInt("CurrentLevel").ToString(), "_Time_Sec"), Mathf.RoundToInt(levelTimeSec));
        PlayerPrefs.SetInt(string.Concat("Level", PlayerPrefs.GetInt("CurrentLevel").ToString(), "_Time_Min"), levelTimeMin);
    }

    public int LoadLevelTimeMin()
    {
        return PlayerPrefs.GetInt(string.Concat("Level", PlayerPrefs.GetInt("CurrentLevel").ToString(), "_Time_Min"));
    }

    public int LoadLevelTimeSec()
    {
        return PlayerPrefs.GetInt(string.Concat("Level", PlayerPrefs.GetInt("CurrentLevel").ToString(), "_Time_Sec"));
    }
}
