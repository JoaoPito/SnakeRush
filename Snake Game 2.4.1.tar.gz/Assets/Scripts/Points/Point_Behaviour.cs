﻿using UnityEngine;
using System.Collections;

public class Point_Behaviour : MonoBehaviour {

    public Material selfMaterial;
    public GameObject Graphics;
    public float blinkTime;
    public float colorTime;
    private bool blink;
    private Transform player;
    public Vector2 playerDistance;

    private bool destroy = false;

    public Color blinkColor1,
        blinkColor2;
    
	void Start () {

        player = GameObject.FindWithTag("Player").transform;

        if (selfMaterial == null)
        {
            selfMaterial = transform.GetComponent<Material>();
        }

        InvokeRepeating("MatBlink", blinkTime, blinkTime);
	
	}

    // Update is called once per frame
    void Update() {

        playerDistance = new Vector2(transform.position.x - player.position.x, transform.position.z - player.position.z);

        if (blink)
        {
            selfMaterial.color = blinkColor1;
        }
        else
        {
            selfMaterial.color = blinkColor2;
        }

        if (!destroy)
        {
            if ((playerDistance.x < 1.15f && playerDistance.x > -1.15f) && (playerDistance.y < 1.15f && playerDistance.y > -1.15f))
            {
                Destroy(Graphics);
                Point_Controller.levelPoints++;
                destroy = true;
                player.GetComponent<Player_Movement>().eat = true;
            }
        }
        else
        {
            Destroy(gameObject, 2);
        }

        if (transform.position.z - player.position.z < -25)
        {
            Destroy(gameObject);
        }

    }

    void MatBlink ()
    {
        blink = !blink;
    }
}
