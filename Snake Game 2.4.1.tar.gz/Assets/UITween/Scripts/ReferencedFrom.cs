﻿using UnityEngine;
using System.Collections;
using UITween;

public class ReferencedFrom : MonoBehaviour { }